setwd("C:\\Users\\user\\OneDrive\\Desktop\\it24103939")

#q1

# Replace with your actual data
laptop_weights <- c(1.2, 1.5, 1.3, 1.6, 1.4, 1.7, 1.3, 1.5, 1.6, 1.4)

# Population mean and standard deviation
pop_mean <- mean(laptop_weights)
pop_sd <- sd(laptop_weights)

cat("Population Mean:", pop_mean, "\n")
cat("Population Standard Deviation:", pop_sd, "\n")


#q2

set.seed(123)  # For reproducibility

sample_means <- numeric(25)
sample_sds <- numeric(25)

for (i in 1:25) {
  sample_i <- sample(laptop_weights, size = 6, replace = TRUE)
  sample_means[i] <- mean(sample_i)
  sample_sds[i] <- sd(sample_i)
}

# Display sample means and standard deviations
data.frame(Sample = 1:25, Mean = sample_means, SD = sample_sds)

#q3

mean_of_sample_means <- mean(sample_means)
sd_of_sample_means <- sd(sample_means)

cat("Mean of Sample Means:", mean_of_sample_means, "\n")
cat("Standard Deviation of Sample Means:", sd_of_sample_means, "\n")

# Relationship to population
cat("Population Mean:", pop_mean, "\n")
cat("Population SD divided by sqrt(n):", pop_sd / sqrt(6), "\n")


