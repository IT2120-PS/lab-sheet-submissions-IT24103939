setwd("C:/Users/user/OneDrive/Desktop/y2 s1/lectures/PS lecture/Lab 05-20250826")

delivery_times <- read.csv("Exercise - Lab 05.txt", header = TRUE, sep = ",")

head(delivery_times)
nrow(delivery_times)
names(delivery_times) <- c("Delivery_Time")

dt <- delivery_times$Delivery_Time

#2
breaks_9 <- seq(20, 70, length.out = 10)

hist(dt,
     breaks = breaks_9,
     main = "Histogram of Delivery Times\n9 Classes (20 to 70)",
     xlab = "Delivery Time (minutes)",
     ylab = "Frequency",
     col = "lightblue",
     border = "black",
     right = FALSE
)

#3
cat("\nComment on the shape of the distribution:\n")
cat("The distribution of delivery times is approximately symmetric ")
cat("with a slight positive skew. Most delivery times are between 35 and 55 minutes. ")
cat("The histogram shows a peak around 35–45 minutes, indicating high frequency in that range. ")
cat("There are no extreme outliers. The spread is moderate, ranging from 20 to 67 minutes.\n")

#4
bins <- cut(dt, breaks = breaks_9, right = FALSE)
freq_table <- table(bins)

midpoints <- (breaks_9[-10] + breaks_9[-1]) / 2

cum_freq <- cumsum(freq_table)
cum_freq_ext <- c(0, cum_freq)

x_ogive <- c(breaks_9[1], midpoints)

plot(x_ogive, cum_freq_ext,
     type = "o",
     col = "blue",
     pch = 16,
     lwd = 2,
     main = "Ogive (Cumulative Frequency Polygon)",
     xlab = "Delivery Time (minutes)",
     ylab = "Cumulative Frequency",
     ylim = c(0, 40))
lines(x_ogive, cum_freq_ext, type = "o", col = "blue", pch = 16, lwd = 2)

# Optional: Print frequency table in console
cat("\nFrequency Distribution Table:\n")
class_intervals <- paste(breaks_9[-10], "-", breaks_9[-1], sep = "")
freq_df <- data.frame(
  "Class Interval" = class_intervals,
  "Frequency" = as.vector(freq_table),
  "Cumulative Frequency" = cum_freq
)
print(freq_df)